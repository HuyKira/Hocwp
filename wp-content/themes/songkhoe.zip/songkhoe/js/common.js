$(document).ready(function(){
    $('.smobitrigger').smplmnu();

    $(".rslides").responsiveSlides({
        pager: true
    });

});